import re
from collections import defaultdict
from typing import Optional, Dict, Set, List

import pywrapfst as fst
import networkx as nx

from .JsgfParserListener import JsgfParserListener


class FSTListener(JsgfParserListener):
    def __init__(
        self,
        input_symbols: fst.SymbolTable,
        output_symbols: fst.SymbolTable,
        eps: str = "<eps>",
    ):
        # Grammar name
        self.grammar_name: Optional[str] = None

        # State
        self.is_public: bool = False
        self.in_rule: bool = False
        self.in_rule_reference: bool = False
        self.rule_name: bool = None

        # Nesting level of groups/optionals
        self.group_depth: int = 0

        # rule name -> state index
        self.last_states: Dict[str, int] = {}

        # group depth -> state index
        self.opt_states: Dict[int, int] = {}
        self.alt_states: Dict[int, int] = {}
        self.alt_ends: Dict[int, int] = {}
        self.tag_states: Dict[int, int] = {}
        self.exp_states: Dict[int, int] = {}

        # FST
        self.grammar_fst: Optional[fst.Fst] = None
        self.fst: Optional[fst.Fst] = None
        self.fsts: Dict[str, fst.Fst] = {}

        self.rule_references: Dict[str, Set[str]] = defaultdict(set)
        self.slot_references: Set[str] = set()
        self.tag_input_symbols: Set[int] = set()

        self.graph = nx.DiGraph()

        # Shared symbol tables
        self.input_symbols: fst.SymbolTable = input_symbols
        self.output_symbols: fst.SymbolTable = output_symbols
        self.weight_one: Optional[fst.Weight] = None

        # Indices of <eps> tokens
        self.in_eps: int = self.input_symbols.find(eps)
        self.out_eps: int = self.output_symbols.find(eps)

    # -------------------------------------------------------------------------

    def enterGrammarName(self, ctx):
        self.grammar_name = ctx.getText()
        self.graph.add_node(self.grammar_name, type="grammar")

    def enterRuleDefinition(self, ctx):
        # Only a single public rule is expected
        self.is_public = ctx.PUBLIC() is not None

    def exitRuleDefinition(self, ctx):
        self.is_public = False
        self.fst.set_final(self.last_states[self.rule_name])

    def enterRuleName(self, ctx):
        # Create qualified rule name
        self.rule_name = self.grammar_name + "." + ctx.getText()
        self.graph.add_node(self.rule_name, type="rule")
        self.graph.add_edge(self.grammar_name, self.rule_name)

    def enterRuleBody(self, ctx):
        self.in_rule = True

        # Create new FST for rule
        self.fst = fst.Fst()
        self.start_state = self.fst.add_state()
        self.fst.set_start(self.start_state)
        self.last_states[self.rule_name] = self.start_state

        if self.weight_one is None:
            self.weight_one = fst.Weight.One(self.fst.weight_type())

        if self.is_public:
            grammar_rule = self.grammar_name + "." + self.grammar_name
            if self.rule_name == grammar_rule:
                self.grammar_fst = self.fst

        # Cache FST
        self.fsts[self.rule_name] = self.fst

        # Reset state
        self.group_depth = 0
        self.opt_states = {}
        self.alt_states = {}
        self.tag_states = {}
        self.exp_states = {}
        self.alt_ends = {}

        # Save anchor state
        self.alt_states[self.group_depth] = self.last_states[self.rule_name]

    def exitRuleBody(self, ctx):
        self.in_rule = False

    def enterExpression(self, ctx):
        self.exp_states[self.group_depth] = self.last_states[self.rule_name]

    # -------------------------------------------------------------------------
    # Groups/Optionals
    # -------------------------------------------------------------------------

    def enterAlternative(self, ctx):
        anchor_state = self.alt_states[self.group_depth]

        if self.group_depth not in self.alt_ends:
            # Patch start of alternative
            next_state = self.fst.add_state()
            for arc in self.fst.arcs(anchor_state):
                self.fst.add_arc(next_state, arc)

            self.fst.delete_arcs(anchor_state)
            self.fst.add_arc(
                anchor_state,
                fst.Arc(self.in_eps, self.out_eps, self.weight_one, next_state),
            )

            # Create shared end state for alternatives
            self.alt_ends[self.group_depth] = self.fst.add_state()

        # Close previous alternative
        last_state = self.last_states[self.rule_name]
        end_state = self.alt_ends[self.group_depth]
        self.fst.add_arc(
            last_state, fst.Arc(self.in_eps, self.out_eps, self.weight_one, end_state)
        )

        # Add new intermediary state
        next_state = self.fst.add_state()
        self.fst.add_arc(
            anchor_state,
            fst.Arc(self.in_eps, self.out_eps, self.weight_one, next_state),
        )
        self.last_states[self.rule_name] = next_state

    def exitAlternative(self, ctx):
        # Create arc to shared end state
        last_state = self.last_states[self.rule_name]
        end_state = self.alt_ends[self.group_depth]
        if last_state != end_state:
            self.fst.add_arc(
                last_state,
                fst.Arc(self.in_eps, self.out_eps, self.weight_one, end_state),
            )

        self.last_states[self.rule_name] = end_state

    def enterOptional(self, ctx):
        # Save anchor state
        self.opt_states[self.group_depth] = self.last_states[self.rule_name]

        # Optionals are honorary groups
        self.group_depth += 1

        # Save anchor state
        self.alt_states[self.group_depth] = self.last_states[self.rule_name]

    def exitOptional(self, ctx):
        # Optionals are honorary groups
        self.alt_ends.pop(self.group_depth, None)
        self.group_depth -= 1

        anchor_state = self.opt_states[self.group_depth]
        last_state = self.last_states[self.rule_name]

        # Add optional by-pass arc
        # --[<eps>]-->
        self.fst.add_arc(
            anchor_state,
            fst.Arc(self.in_eps, self.out_eps, self.weight_one, last_state),
        )

    def enterGroup(self, ctx):
        self.group_depth += 1

        # Save anchor state for alternatives
        self.alt_states[self.group_depth] = self.last_states[self.rule_name]

    def exitGroup(self, ctx):
        # Clear end state for alternatives
        self.alt_ends.pop(self.group_depth, None)
        self.group_depth -= 1

    # -------------------------------------------------------------------------
    # Rule References
    # -------------------------------------------------------------------------

    def enterRuleReference(self, ctx):
        self.in_rule_reference = True
        rule_name = ctx.getText()[1:-1]
        if "." not in rule_name:
            # Assume current grammar
            rule_name = self.grammar_name + "." + rule_name

        self.rule_references[self.rule_name].add(rule_name)

        self.graph.add_node(rule_name, type="reference")
        self.graph.add_edge(self.rule_name, rule_name)

        # Create transition that will be replaced with a different FST
        rule_symbol = "__replace__" + rule_name
        input_idx = self.input_symbols.add_symbol(rule_symbol)
        output_idx = self.output_symbols.add_symbol(rule_symbol)

        # --[__replace__RULE]-->
        last_state = self.last_states[self.rule_name]
        next_state = self.fst.add_state()
        self.fst.add_arc(
            last_state, fst.Arc(input_idx, output_idx, self.weight_one, next_state)
        )
        self.last_states[self.rule_name] = next_state

    def exitRuleReference(self, ctx):
        self.in_rule_reference = False

    # -------------------------------------------------------------------------
    # Tags
    # -------------------------------------------------------------------------

    def enterTagBody(self, ctx):
        # Get the original text *with* whitespace from ANTLR
        input_stream = ctx.start.getInputStream()
        start = ctx.start.start
        stop = ctx.stop.stop
        tag_text = input_stream.getText(start, stop)

        # Patch start of tag
        anchor_state = self.exp_states[self.group_depth]
        next_state = self.fst.add_state()

        # --[__begin__TAG]-->
        begin_symbol = "__begin__" + tag_text
        input_idx = self.input_symbols.add_symbol(begin_symbol)
        output_idx = self.output_symbols.add_symbol(begin_symbol)

        self.tag_input_symbols.add(input_idx)

        # Move outgoing anchor arcs
        for arc in self.fst.arcs(anchor_state):
            self.fst.add_arc(
                next_state, fst.Arc(arc.ilabel, arc.olabel, arc.weight, arc.nextstate)
            )

        # Patch anchor
        self.fst.delete_arcs(anchor_state)
        self.fst.add_arc(
            anchor_state, fst.Arc(input_idx, output_idx, self.weight_one, next_state)
        )

        # Patch end of tag
        last_state = self.last_states[self.rule_name]
        next_state = self.fst.add_state()

        # --[__end__TAG]-->
        end_symbol = "__end__" + tag_text
        input_idx = self.input_symbols.add_symbol(end_symbol)
        output_idx = self.output_symbols.add_symbol(end_symbol)

        self.tag_input_symbols.add(input_idx)

        self.fst.add_arc(
            last_state, fst.Arc(input_idx, output_idx, self.weight_one, next_state)
        )
        self.last_states[self.rule_name] = next_state

    # -------------------------------------------------------------------------
    # Literals
    # -------------------------------------------------------------------------

    def enterLiteral(self, ctx):
        if (not self.in_rule) or self.in_rule_reference:
            return

        # Get the original text *with* whitespace from ANTLR
        input_stream = ctx.start.getInputStream()
        start = ctx.start.start
        stop = ctx.stop.stop
        text = input_stream.getText(start, stop)

        last_state = self.last_states[self.rule_name]

        # Split words by whitespace
        for word in re.split(r"\s+", text):
            if ":" in word:
                # Word contains input:output pair
                input_symbol = word.split(":", maxsplit=1)[0]

                # NOTE: Entire word (with ":") is used as the output symbol so
                # that the fstaccept method can know what the original (raw)
                # text was.
                output_symbol = word
            elif word.startswith("$"):
                # Slot replacement
                input_symbol = "__replace__" + word
                output_symbol = input_symbol
                slot_name = word[1:]
                self.slot_references.add(slot_name)
                self.graph.add_node(slot_name, type="slot")
                self.graph.add_edge(self.rule_name, slot_name)
            else:
                # Word itself is input and output
                input_symbol, output_symbol = word, word

            input_idx = self.input_symbols.add_symbol(input_symbol)
            output_idx = self.output_symbols.add_symbol(output_symbol)

            # --[word_in:word_out]-->
            next_state = self.fst.add_state()
            self.fst.add_arc(
                last_state, fst.Arc(input_idx, output_idx, self.weight_one, next_state)
            )
            self.exp_states[self.group_depth] = last_state
            last_state = next_state

        self.last_states[self.rule_name] = last_state
