import re
from collections import defaultdict
from typing import Optional, Dict, Set, List
import networkx as nx

from .JsgfParserListener import JsgfParserListener

# -----------------------------------------------------------------------------


class GrammarDependencies:
    def __init__(self):
        self.graph = nx.DiGraph()
        self.input_words: Set[str] = set()
        self.output_words: Set[str] = set()


# -----------------------------------------------------------------------------


class RuleSlotListener(JsgfParserListener):
    def __init__(self, deps: GrammarDependencies):
        # State
        self.grammar_name: Optional[str] = None
        self.in_rule: bool = False
        self.in_rule_reference: bool = False
        self.rule_name: Optional[str] = None

        # Names of referenced rules/slots
        self.grammar_references: Set[str] = set()
        self.rule_references: Set[str] = set()
        self.slot_references: Set[str] = set()

        self.deps = deps

    # -------------------------------------------------------------------------

    def enterGrammarName(self, ctx):
        self.grammar_name = ctx.getText()
        self.deps.graph.add_node(self.grammar_name, type="grammar")

    def enterRuleBody(self, ctx):
        self.in_rule = True

    def exitRuleBody(self, ctx):
        self.in_rule = False

    # -------------------------------------------------------------------------
    # Rule References
    # -------------------------------------------------------------------------

    def enterRuleReference(self, ctx):
        self.in_rule_reference = True
        rule_name = ctx.getText()[1:-1]
        if "." not in rule_name:
            # Assume current grammar
            rule_name = self.grammar_name + "." + rule_name

            # Record reference to rule
            self.deps.graph.add_node(rule_name, type="rule")

        rule_grammar_name = rule_name.split(".", maxsplit=1)[0]
        if rule_grammar_name != self.grammar_name:
            # Record reference to other grammar
            self.deps.graph.add_node(rule_grammar_name, type="grammar")
            self.deps.graph.add_edge(self.grammar_name, rule_grammar_name)

            # Record reference to other grammar's rule
            self.deps.graph.add_node(rule_name, type="reference")

        self.deps.graph.add_edge(rule_grammar_name, rule_name)
        self.rule_name = rule_name

        # Add replacement symbol
        rule_symbol = "__replace__" + rule_name
        input_idx = self.deps.input_words.add(rule_symbol)
        output_idx = self.deps.output_words.add(rule_symbol)

    def exitRuleReference(self, ctx):
        self.in_rule_reference = False

    # -------------------------------------------------------------------------
    # Tags
    # -------------------------------------------------------------------------

    def enterTagBody(self, ctx):
        # Get the original text *with* whitespace from ANTLR
        input_stream = ctx.start.getInputStream()
        start = ctx.start.start
        stop = ctx.stop.stop
        tag_text = input_stream.getText(start, stop)

        # --[__begin__TAG]-->
        begin_symbol = "__begin__" + tag_text
        input_idx = self.deps.input_words.add(begin_symbol)
        output_idx = self.deps.output_words.add(begin_symbol)

        # --[__end__TAG]-->
        end_symbol = "__end__" + tag_text
        input_idx = self.deps.input_words.add(end_symbol)
        output_idx = self.deps.output_words.add(end_symbol)

    # -------------------------------------------------------------------------
    # Literals
    # -------------------------------------------------------------------------

    def enterLiteral(self, ctx):
        if (not self.in_rule) or self.in_rule_reference:
            return

        # Get the original text *with* whitespace from ANTLR
        input_stream = ctx.start.getInputStream()
        start = ctx.start.start
        stop = ctx.stop.stop
        text = input_stream.getText(start, stop)

        # Split words by whitespace
        for word in re.split(r"\s+", text):
            if ":" in word:
                in_word = word.split(":", maxsplit=1)[0]
                self.deps.input_words.add(in_word)

                # NOTE: Entire word (with ":") is used as output
                self.deps.output_words.add(word)
            elif word.startswith("$"):
                slot_name = word[1:]

                # Record reference to slot
                self.deps.graph.add_node(slot_name, type="slot")
                self.deps.graph.add_edge(self.rule_name, slot_name)

                replace_symbol = "__replace__" + word
                self.deps.input_words.add(replace_symbol)
                self.deps.output_words.add(replace_symbol)
            else:
                self.deps.input_words.add(word)
                self.deps.output_words.add(word)
