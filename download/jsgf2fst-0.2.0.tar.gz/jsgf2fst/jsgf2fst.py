#!/usr/bin/env python3
import os
import sys
import argparse
import re
import io
import subprocess
import tempfile
import shutil
import itertools
import collections
from collections import defaultdict, deque
import logging
from pathlib import Path
from typing import Set, List, Dict, Union, Any, Tuple, Optional

import antlr4
import pywrapfst as fst
import networkx as nx

from .JsgfParser import JsgfParser
from .JsgfLexer import JsgfLexer
from .JsgfParserListener import JsgfParserListener

from .FSTListener import FSTListener
from .RuleSlotListener import RuleSlotListener, GrammarDependencies

logger = logging.getLogger("jsgf2fst")


def main() -> None:
    logging.basicConfig(level=logging.DEBUG)

    parser = argparse.ArgumentParser("jsgf2fst")
    parser.add_argument("grammars", nargs="+", help="JSGF grammars to convert")
    parser.add_argument("--out-dir", default=".", help="Directory to write FST files")
    parser.add_argument("--intent-fst", default=None, help="Path to write intent FST")
    parser.add_argument(
        "--slots-dir", default=None, help="Directory to read slot files"
    )
    parser.add_argument("--no-slots", action="store_true", help="Don't expand $slots")
    args = parser.parse_args()

    # TODO: Fix
    # # Create output directory
    # os.makedirs(args.out_dir, exist_ok=True)

    # # Load JSGF grammars
    # grammars = []
    # for grammar_path in args.grammars:
    #     logger.debug(f"Parsing {grammar_path}")
    #     grammars.append(jsgf.parse_grammar_file(grammar_path))

    # if not args.no_slots and args.slots_dir:
    #     # Directory where slot values are stored ($slot_name -> dir/slot_name)
    #     slots = read_slots(args.slots_dir)
    # else:
    #     slots = {}  # no slots

    # # Convert to FSTs
    # grammar_fsts = jsgf2fst(grammars, slots=slots)

    # # Write FSTs
    # for grammar_name, grammar_fst in grammar_fsts.items():
    #     fst_path = os.path.abspath(os.path.join(args.out_dir, f"{grammar_name}.fst"))
    #     grammar_fst.write(fst_path)
    #     logger.info(f"Wrote grammar FST to {fst_path}")

    # if args.intent_fst:
    #     intent_fst = make_intent_fst(grammar_fsts)
    #     intent_fst.write(args.intent_fst)
    #     logger.info(f"Wrote intent FST to {args.intent_fst}")


# -----------------------------------------------------------------------------


def jsgf2fst(
    grammar_paths: Union[Path, List[Path]],
    slots: Dict[str, List[str]] = {},
    eps: str = "<eps>",
) -> Dict[str, fst.Fst]:
    """Converts JSGF grammars to FSTs.
    Returns dictionary mapping grammar names to FSTs."""

    # TODO: Fix
    is_list = isinstance(grammar_paths, collections.Iterable)
    # if not is_list:
    #     grammar_paths = [grammar_paths]

    # # grammar name -> fst
    # grammar_fsts: Dict[str, fst.Fst] = {}

    # # rule name -> fst
    # rule_fsts: Dict[str, fst.Fst] = {}

    # # rule name -> fst
    # replaced_fsts: Dict[str, fst.Fst] = {}

    # # grammar name -> listener
    # listeners: Dict[str, FSTListener] = {}

    # # Share symbol tables between all FSTs
    # input_symbols = fst.SymbolTable()
    # output_symbols = fst.SymbolTable()
    # input_symbols.add_symbol(eps)
    # output_symbols.add_symbol(eps)

    # # Set of all input symbols that are __begin__ or __end__
    # tag_input_symbols: Set[int] = set()

    # # Set of all slot names that were used
    # slots_to_replace: Set[str] = set()

    # # Process each grammar
    # for grammar_path in grammar_paths:
    #     logger.debug(f"Processing {grammar_path}")

    #     with open(grammar_path, "r") as grammar_file:
    #         # Tokenize
    #         input_stream = antlr4.InputStream(grammar_file.read())
    #         lexer = JsgfLexer(input_stream)
    #         tokens = antlr4.CommonTokenStream(lexer)

    #         # Parse
    #         parser = JsgfParser(tokens)

    #         # Transform to FST
    #         context = parser.r()
    #         walker = antlr4.ParseTreeWalker()

    #         # Create FST and symbol tables
    #         grammar_fst = fst.Fst()

    #         start = grammar_fst.add_state()
    #         grammar_fst.set_start(start)

    #         listener = FSTListener(grammar_fst, input_symbols, output_symbols, start)
    #         walker.walk(listener, context)

    #         # Merge with set of all tag input symbols
    #         tag_input_symbols.update(listener.tag_input_symbols)

    #         # Merge with set of all used slots
    #         slots_to_replace.update(listener.slot_references)

    #         # Save FSTs for all rules
    #         for rule_name, rule_fst in listener.fsts.items():
    #             rule_fsts[rule_name] = rule_fst
    #             listeners[rule_name] = listener

    #             # Record FSTs that have no rule references
    #             if len(listener.rule_references[rule_name]) == 0:
    #                 replaced_fsts[rule_name] = rule_fst

    #         # Save for later
    #         grammar_fsts[listener.grammar_name] = grammar_fst

    # # -------------------------------------------------------------------------

    # # grammar name -> (slot names)
    # def replace_fsts(rule_name):
    #     nonlocal replaced_fsts, slots_to_replace
    #     rule_fst = replaced_fsts.get(rule_name)
    #     if rule_fst is not None:
    #         return rule_fst

    #     listener = listeners[rule_name]

    #     rule_fst = rule_fsts[rule_name]
    #     for ref_name in listener.rule_references[rule_name]:
    #         ref_fst = replace_fsts(ref_name)

    #         # Replace rule in grammar FST
    #         replace_symbol = "__replace__" + ref_name
    #         replace_idx = output_symbols.find(replace_symbol)
    #         if replace_idx >= 0:
    #             logger.debug(f"Replacing rule {ref_name} in {rule_name}")
    #             rule_fst = fst.replace(
    #                 [(-1, rule_fst), (replace_idx, ref_fst)], epsilon_on_replace=True
    #             )

    #     replaced_fsts[rule_name] = rule_fst
    #     return rule_fst

    # # Do rule replacements
    # for grammar_name in list(grammar_fsts.keys()):
    #     main_rule_name = grammar_name + "." + grammar_name
    #     grammar_fsts[grammar_name] = replace_fsts(main_rule_name)

    # # -------------------------------------------------------------------------

    # # Do slot replacements
    # slot_fsts: Dict[str, fst.Fst] = {}
    # for grammar_name, grammar_fst in grammar_fsts.items():
    #     main_rule_name = grammar_name + "." + grammar_name
    #     listener = listeners[main_rule_name]

    #     for slot_name in slots_to_replace:
    #         if slot_name not in slot_fsts:
    #             # Create FST for slot values
    #             logger.debug(f"Creating FST for slot {slot_name}")

    #             slot_fst = fst.Fst()
    #             start = slot_fst.add_state()
    #             slot_fst.set_start(start)

    #             # Create a single slot grammar
    #             with io.StringIO() as text_file:
    #                 print("#JSGF v1.0;", file=text_file)
    #                 print(f"grammar {slot_name};", file=text_file)
    #                 print("", file=text_file)

    #                 choices = " | ".join(
    #                     [
    #                         "(" + v + ")"
    #                         for v in itertools.chain(
    #                             slots.get_text(slot_name), slots.get_jsgf(slot_name)
    #                         )
    #                     ]
    #                 )

    #                 # All slot values
    #                 print(f"public <{slot_name}> = ({choices});", file=text_file)
    #                 text_file.seek(0)

    #                 # Tokenize
    #                 input_stream = antlr4.InputStream(text_file.getvalue())
    #                 lexer = JsgfLexer(input_stream)
    #                 tokens = antlr4.CommonTokenStream(lexer)

    #                 # Parse
    #                 parser = JsgfParser(tokens)

    #                 # Transform to FST
    #                 context = parser.r()
    #                 walker = antlr4.ParseTreeWalker()

    #                 # Fill in slot_fst
    #                 slot_listener = FSTListener(
    #                     slot_fst, input_symbols, output_symbols, start
    #                 )
    #                 walker.walk(slot_listener, context)

    #             # Cache for other grammars
    #             slot_fsts[slot_name] = slot_fst

    #         # -----------------------------------------------------------------

    #         # Replace slot in grammar FST
    #         replace_symbol = "__replace__$" + slot_name
    #         replace_idx = output_symbols.find(replace_symbol)
    #         if replace_idx >= 0:
    #             logger.debug(f"Replacing slot {slot_name} in {main_rule_name}")
    #             grammar_fst = fst.replace(
    #                 [(-1, grammar_fst), (replace_idx, slot_fst)],
    #                 epsilon_on_replace=True,
    #             )

    #             grammar_fsts[grammar_name] = grammar_fst

    # # -------------------------------------------------------------------------

    # # Remove tag start symbols.
    # # TODO: Only do this for FSTs that actually have tags.
    # for grammar_name, grammar_fst in grammar_fsts.items():
    #     main_rule_name = grammar_name + "." + grammar_name
    #     listener = listeners[main_rule_name]

    #     # Create a copy of the grammar FST with __begin__ and __end__ input
    #     # labels replaced by <eps>. For some reason, fstreplace fails when this
    #     # is done beforehand, whining about cyclic dependencies.
    #     in_eps = input_symbols.find(eps)
    #     old_fst = grammar_fst
    #     grammar_fst = fst.Fst()
    #     state_map: Dict[int, int] = {}
    #     weight_zero = fst.Weight.Zero(old_fst.weight_type())

    #     # Copy states with final status
    #     for old_state in old_fst.states():
    #         new_state = grammar_fst.add_state()
    #         state_map[old_state] = new_state
    #         if old_fst.final(old_state) != weight_zero:
    #             grammar_fst.set_final(new_state)

    #     # Start state
    #     grammar_fst.set_start(state_map[old_fst.start()])

    #     # Copy arcs
    #     for old_state, new_state in state_map.items():
    #         for old_arc in old_fst.arcs(old_state):
    #             # Replace tag input labels with <eps>
    #             input_idx = (
    #                 in_eps if old_arc.ilabel in tag_input_symbols else old_arc.ilabel
    #             )

    #             grammar_fst.add_arc(
    #                 new_state,
    #                 fst.Arc(
    #                     input_idx,
    #                     old_arc.olabel,
    #                     fst.Weight.One(grammar_fst.weight_type()),
    #                     state_map[old_arc.nextstate],
    #                 ),
    #             )

    #     grammar_fst.set_input_symbols(input_symbols)
    #     grammar_fst.set_output_symbols(output_symbols)

    #     # Replace FST
    #     grammar_fsts[grammar_name] = grammar_fst

    # # -------------------------------------------------------------------------

    # if not is_list:
    #     # Single input, single output
    #     return next(iter(grammar_fsts.values()))

    # return grammar_fsts


# -----------------------------------------------------------------------------


def make_intent_fst(
    grammar_fsts: Dict[str, fst.Fst],
    input_symbols: fst.SymbolTable,
    output_symbols: fst.SymbolTable,
    eps: str = "<eps>",
) -> fst.Fst:
    """Merges grammar FSTs created with jsgf2fst into a single acceptor FST."""
    in_eps: int = input_symbols.find(eps)
    out_eps: int = output_symbols.find(eps)

    intent_fst = fst.Fst()
    weight_one = fst.Weight.One(intent_fst.weight_type())

    # Create start/final states
    start_state = intent_fst.add_state()
    intent_fst.set_start(start_state)

    final_state = intent_fst.add_state()
    intent_fst.set_final(final_state)

    replacements = [(-1, intent_fst)]

    for intent, grammar_fst in grammar_fsts.items():
        intent_label = f"__label__{intent}"
        out_label = output_symbols.add_symbol(intent_label)

        # --[__label__INTENT]-->
        intent_start = intent_fst.add_state()
        intent_fst.add_arc(
            start_state, fst.Arc(in_eps, out_label, weight_one, intent_start)
        )

        # --[__replace__INTENT]-->
        intent_end = intent_fst.add_state()
        replace_symbol = f"__replace__{intent}"
        in_replace = input_symbols.add_symbol(replace_symbol)
        out_replace = output_symbols.add_symbol(replace_symbol)
        intent_fst.add_arc(
            intent_start, fst.Arc(in_replace, out_replace, weight_one, intent_end)
        )

        # --[eps]-->
        intent_fst.add_arc(
            intent_end, fst.Arc(in_eps, out_eps, weight_one, final_state)
        )

        replacements.append((out_replace, grammar_fst))

    # Replace
    intent_fst = fst.replace(replacements, epsilon_on_replace=True)

    # Fix symbol tables
    intent_fst.set_input_symbols(input_symbols)
    intent_fst.set_output_symbols(output_symbols)

    return intent_fst


# -----------------------------------------------------------------------------


def get_parser(grammar: str) -> JsgfParser:
    """Returns a JSGF parser for a JSGF grammar."""
    # Tokenize
    input_stream = antlr4.InputStream(grammar)
    lexer = JsgfLexer(input_stream)
    tokens = antlr4.CommonTokenStream(lexer)

    # Parse
    return JsgfParser(tokens)


def grammar_dependencies(grammar: str) -> GrammarDependencies:
    """Gets dependency graph for JSGF grammar."""
    # Parse
    parser = get_parser(grammar)
    context = parser.r()
    walker = antlr4.ParseTreeWalker()

    deps = GrammarDependencies()
    listener = RuleSlotListener(deps)
    walker.walk(listener, context)

    return deps


def grammar_to_fsts(
    grammar: str,
    input_symbols: Optional[fst.SymbolTable] = None,
    output_symbols: Optional[fst.SymbolTable] = None,
    eps: str = "<eps>",
) -> Tuple[str, Dict[str, fst.Fst]]:
    """Transforms JSGF grammar into FSTs, one for each rule."""
    # Parse
    parser = get_parser(grammar)
    context = parser.r()
    walker = antlr4.ParseTreeWalker()

    if input_symbols is None:
        input_symbols = fst.SymbolTable()

    input_symbols.add_symbol(eps)

    if output_symbols is None:
        output_symbols = fst.SymbolTable()

    output_symbols.add_symbol(eps)

    # Generate FST
    listener = FSTListener(input_symbols, output_symbols, eps=eps)
    walker.walk(listener, context)

    # Fix symbol tables
    for rule_fst in listener.fsts.values():
        rule_fst.set_input_symbols(input_symbols)
        rule_fst.set_output_symbols(output_symbols)

    # Do replacements of local rules
    graph = listener.graph
    postorder = nx.algorithms.traversal.dfs_postorder_nodes(
        listener.graph, listener.grammar_name
    )

    for node in postorder:
        node_type = graph.nodes[node]["type"]
        if node_type == "rule":
            for child_node in graph.successors(node):
                child_fst = listener.fsts.get(child_node)
                if child_fst is not None:
                    replace_symbol = "__replace__" + child_node
                    replace_idx = output_symbols.find(replace_symbol)
                    if replace_idx >= 0:
                        logger.debug(f"Replacing rule {child_node} in {node}")
                        listener.fsts[node] = fst.replace(
                            [(-1, listener.fsts[node]), (replace_idx, child_fst)],
                            epsilon_on_replace=True,
                        )

    main_rule = listener.grammar_name + "." + listener.grammar_name

    return listener.grammar_name, listener.fsts


def slot_to_grammar(slots_dir: Path, slot_name: str):
    """Creates JSGF grammar for a slot file."""
    slot_path = slots_dir / slot_name
    with io.StringIO() as grammar_file:
        with open(slot_path, "r") as slot_file:
            choices = "|".join(f"({line.strip()})" for line in slot_file)
            print("#JSGF v1.0;", file=grammar_file)
            print(f"grammar {slot_name};", file=grammar_file)
            print(f"public <{slot_name}> = ({choices});", file=grammar_file)

        return grammar_file.getvalue()


def replace_tag_symbols(the_fst: fst.Fst, eps="<eps>") -> fst.Fst:
    """Replaces __begin__ and __end__ input tab symbols in an FST with <eps>."""
    input_symbols = the_fst.input_symbols()
    tag_input_symbols: Set[int] = set()

    for i in range(input_symbols.num_symbols()):
        symbol = input_symbols.find(i).decode()
        if symbol.startswith("__begin__") or symbol.startswith("__end__"):
            tag_input_symbols.add(i)

    if len(tag_input_symbols) == 0:
        # No symbols to replace
        return the_fst

    # Create a copy of the FST with __begin__ and __end__ input
    # labels replaced by <eps>. For some reason, fstreplace fails when this
    # is done beforehand, whining about cyclic dependencies.
    in_eps = input_symbols.find(eps)
    old_fst = the_fst
    new_fst = fst.Fst()
    state_map: Dict[int, int] = {}
    weight_zero = fst.Weight.Zero(old_fst.weight_type())
    weight_one = fst.Weight.One(new_fst.weight_type())

    # Copy states with final status
    for old_state in old_fst.states():
        new_state = new_fst.add_state()
        state_map[old_state] = new_state
        if old_fst.final(old_state) != weight_zero:
            new_fst.set_final(new_state)

    # Start state
    new_fst.set_start(state_map[old_fst.start()])

    # Copy arcs
    for old_state, new_state in state_map.items():
        for old_arc in old_fst.arcs(old_state):
            # Replace tag input labels with <eps>
            input_idx = (
                in_eps if old_arc.ilabel in tag_input_symbols else old_arc.ilabel
            )

            new_fst.add_arc(
                new_state,
                fst.Arc(
                    input_idx, old_arc.olabel, weight_one, state_map[old_arc.nextstate]
                ),
            )

    new_fst.set_input_symbols(input_symbols)
    new_fst.set_output_symbols(the_fst.output_symbols())

    return new_fst


# -----------------------------------------------------------------------------

if __name__ == "__main__":
    main()
