var searchData=
[
  ['data_5f',['data_',['../classfasttext_1_1Matrix.html#a3a63d6e3e3db63e5f756bbc4692a46ae',1,'fasttext::Matrix::data_()'],['../classfasttext_1_1Vector.html#ab177f24ed7071636dcd17e90a746dd2e',1,'fasttext::Vector::data_()']]],
  ['dfs',['dfs',['../classfasttext_1_1Model.html#a16ffdb3fcd27fa51f6b435b3be762a77',1,'fasttext::Model']]],
  ['dict_5f',['dict_',['../classfasttext_1_1FastText.html#a2f5648d532a7ff4f46ac425197082422',1,'fasttext::FastText']]],
  ['dictionary',['Dictionary',['../classfasttext_1_1Dictionary.html',1,'fasttext::Dictionary'],['../classfasttext_1_1Dictionary.html#ae0f87ea47dcc779231cd0d2cd660739e',1,'fasttext::Dictionary::Dictionary()']]],
  ['dictionary_2ecc',['dictionary.cc',['../dictionary_8cc.html',1,'']]],
  ['dictionary_2eh',['dictionary.h',['../dictionary_8h.html',1,'']]],
  ['dim',['dim',['../classfasttext_1_1Args.html#a76595eefd3fcfd980d1d4d2fa57dbaf3',1,'fasttext::Args']]],
  ['dim_5f',['dim_',['../classfasttext_1_1ProductQuantizer.html#afdeec3948e983b1f3e1e36292153e300',1,'fasttext::ProductQuantizer']]],
  ['discard',['discard',['../classfasttext_1_1Dictionary.html#a13572c258fc013c30b2dcf7cada260b5',1,'fasttext::Dictionary']]],
  ['distl2',['distL2',['../namespacefasttext.html#a4336b1849ad0c1f134ed0ac9842f053c',1,'fasttext']]],
  ['dividerow',['divideRow',['../classfasttext_1_1Matrix.html#ab4d6dd58db43dd2c4a6fbb12c74541a0',1,'fasttext::Matrix']]],
  ['dotrow',['dotRow',['../classfasttext_1_1Matrix.html#ae6b962ed2ca31fb3a8d094c8f85d6136',1,'fasttext::Matrix::dotRow()'],['../classfasttext_1_1QMatrix.html#ad1671bceb60d87492b662331cc084c56',1,'fasttext::QMatrix::dotRow()']]],
  ['dsub',['dsub',['../classfasttext_1_1Args.html#a7ee03404aa6c513ee8cc4b07715977c5',1,'fasttext::Args']]],
  ['dsub_5f',['dsub_',['../classfasttext_1_1ProductQuantizer.html#a9221f241be27487c671bbbba7a84b389',1,'fasttext::ProductQuantizer']]]
];
