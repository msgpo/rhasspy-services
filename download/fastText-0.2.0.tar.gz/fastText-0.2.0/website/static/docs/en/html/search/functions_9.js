var searchData=
[
  ['kmeans',['kmeans',['../classfasttext_1_1ProductQuantizer.html#a06c91357dc88225714daa10548525352',1,'fasttext::ProductQuantizer']]]
];
