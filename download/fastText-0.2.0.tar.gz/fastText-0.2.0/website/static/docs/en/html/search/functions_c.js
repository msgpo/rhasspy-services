var searchData=
[
  ['negativesampling',['negativeSampling',['../classfasttext_1_1Model.html#a670d5e0695fe61398ec4a2352c897660',1,'fasttext::Model']]],
  ['ngramvectors',['ngramVectors',['../classfasttext_1_1FastText.html#a62a84e26a04b64eb35edfa110dd8dc32',1,'fasttext::FastText']]],
  ['nlabels',['nlabels',['../classfasttext_1_1Dictionary.html#a610cf116879e0897f286ea9dd8c09895',1,'fasttext::Dictionary']]],
  ['nn',['nn',['../classfasttext_1_1FastText.html#a5509f491ca6c2fa3e57bc3443536f885',1,'fasttext::FastText::nn()'],['../main_8cc.html#a821b5934bab6d9d7daf366e92a4621e4',1,'nn():&#160;main.cc']]],
  ['norm',['norm',['../classfasttext_1_1Vector.html#aa88e78466e3db802c403f6fe13421ff6',1,'fasttext::Vector']]],
  ['ntokens',['ntokens',['../classfasttext_1_1Dictionary.html#a8b4d977429d7c264a9fcc4765b2e3972',1,'fasttext::Dictionary']]],
  ['nwords',['nwords',['../classfasttext_1_1Dictionary.html#ad8f09843ce250ad1bca19bb849e8111d',1,'fasttext::Dictionary']]]
];
