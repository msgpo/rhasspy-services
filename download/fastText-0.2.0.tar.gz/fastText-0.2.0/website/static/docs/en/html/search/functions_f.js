var searchData=
[
  ['qmatrix',['QMatrix',['../classfasttext_1_1QMatrix.html#a976442aaed5b1afee2f2cd4473c0d62b',1,'fasttext::QMatrix::QMatrix()'],['../classfasttext_1_1QMatrix.html#ae10f3f12bf4c8483381ecb122b7fda5a',1,'fasttext::QMatrix::QMatrix(const Matrix &amp;, int32_t, bool)']]],
  ['quantize',['quantize',['../classfasttext_1_1FastText.html#aa01f053de2afa22056c594d96988c1ad',1,'fasttext::FastText::quantize()'],['../classfasttext_1_1QMatrix.html#ab9ae1914dc1b72e305880a8c22626afc',1,'fasttext::QMatrix::quantize()'],['../main_8cc.html#a6e07bb2da057cf6a518eed616b490bdd',1,'quantize():&#160;main.cc']]],
  ['quantizenorm',['quantizeNorm',['../classfasttext_1_1QMatrix.html#a0e4d84be1c6cd0cbfc4568f905961017',1,'fasttext::QMatrix']]]
];
