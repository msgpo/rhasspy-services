var searchData=
[
  ['kmeans',['kmeans',['../classfasttext_1_1ProductQuantizer.html#a06c91357dc88225714daa10548525352',1,'fasttext::ProductQuantizer']]],
  ['ksub_5f',['ksub_',['../classfasttext_1_1ProductQuantizer.html#afa68c0f82fab09a93c2024a4dceecdf7',1,'fasttext::ProductQuantizer']]]
];
