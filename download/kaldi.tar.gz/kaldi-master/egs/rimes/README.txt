Rimes is a French handwriting recognition database created by A2iA.
The database was created by asking individuals to write letters on a given scenario like
a change of personal information, payment difficulty, damage declaration. The
dataset has been used in several international research including ICFHR 2008,
ICDAR-2009, ICDAR-2011 competitions for isolated word level and
line level recognition tasks.

It contains 11333 training lines and 788 test lines. It does not include
a validation split but in a recent publication a 10% sampling of the total
training lines for validation purposes were performed
(http://www.jpuigcerver.net/pubs/jpuigcerver_icdar2017.pdf).
We have used a similar train, test and validation split.
More info: http://www.a2ialab.com/doku.php?id=rimes_database:start
