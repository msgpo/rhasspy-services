
  The TIDIGITS database consists of men, women, boys and girls reading
  digit strings of varying lengths; these are sampled at 20 kHz.
  It's available from the LDC as catalog number LDC93S10.

  The subdirectory s5 consists of "s5-style" (i.e. new, at the current
  time of writing) scripts for training and testing.  Note: unlike the
  other s5 scripts we don't include word-boundary information, since it
  wouldn't add anything useful.

