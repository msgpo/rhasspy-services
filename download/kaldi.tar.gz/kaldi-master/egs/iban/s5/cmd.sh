#export train_cmd="run.pl --max-jobs-run 32"
#export decode_cmd="run.pl --max-jobs-run 32"

export train_cmd="queue.pl"
export decode_cmd="queue.pl --mem 4G"
