These files were copy-pasted from ATLAS 3.10.2. We don't anticipate
them changing. These are included here because system-provided
versions of these two files are not in consistent locations.
