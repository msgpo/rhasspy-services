.. _jsgf-ext-expansions:

:py:mod:`expansions` --- Extension expansion classes and functions module
=========================================================================

.. automodule:: jsgf.ext.expansions

=======
Classes
=======

.. autoclass:: Dictation
   :members:

=========
Functions
=========

.. autofunction:: calculate_expansion_sequence
.. autofunction:: expand_dictation_expansion


