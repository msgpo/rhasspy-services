.. _jsgf-ext-grammars:

:py:mod:`grammars` --- Extension grammar classes module
=======================================================

.. automodule:: jsgf.ext.grammars

=======
Classes
=======

.. autoclass:: DictationGrammar
   :members:
