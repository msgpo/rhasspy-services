.. _jsgf-references:

:py:mod:`references` --- References module
===============================================================

.. automodule:: jsgf.references

=======
Classes
=======

.. autoclass:: BaseRef
   :members:
