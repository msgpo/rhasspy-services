.. _jsgf-parser:

:py:mod:`parser` --- Parser module
===============================================================

.. automodule:: jsgf.parser

=========
Functions
=========

.. autofunction:: parse_expansion_string
.. autofunction:: parse_grammar_file
.. autofunction:: parse_grammar_string
.. autofunction:: parse_rule_string
.. autofunction:: valid_grammar
