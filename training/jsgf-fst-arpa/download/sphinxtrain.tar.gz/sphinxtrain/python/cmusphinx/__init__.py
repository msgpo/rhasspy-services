"""\
SphinxTrain Python Modules.
"""

__all__ = ['arpalm', 'mfcc', 'mllt', 's2mfc', 's3file',
           's3gaucnt', 's3gau', 's3lda', 's3mdef', 'mllr',
           's3mixw', 's3model', 's3tmat', 's3dict', 's3senmgau',
           'feat', 'gmm', 'divergence', 'hypseg', 'lattice',
           'hmm', 'htkmfc', 'mllt']

__author__ = "David Huggins-Daines <dhuggins@cs.cmu.edu>"
__version__ = "$Revision$"
